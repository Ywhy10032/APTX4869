# APTX4869 手机端

这是一个独立的安卓 BLE 控制应用，用于控制合法拥有的 `ANKNI YWTD` 设备。

## 工程位置

`E:\App\PhoneApp\APTX4869`

## 技术栈

- Kotlin
- Jetpack Compose
- Material 3 动态配色
- Android 原生 BluetoothGatt API
- 最低 Android 8（API 26）
- 目标 Android 16（API 36）

## 已实现功能

- 扫描并连接 `ANKNI YWTD` / `10:11:DD:02:16:E5`
- 10 种节奏模式；再次点击当前模式停止
- 0–100 线性强度，拖动时实时应用
- 爆发、随机、暂停、继续
- 停止全部振动
- 单按钮切换浅色/深色主题，以全屏圆形水波扩散过渡，并记忆上次选择
- Android 12 及以上附近设备权限适配
- Android 11 及以下传统蓝牙/定位权限适配
- 显示最近一次 DDD1 写入和 DDD2 通知校验状态

## 协议安全边界

- 仅访问服务 `DDDD`
- 仅向控制特征 `DDD1` 写入已抓包验证的指令
- 仅订阅状态特征 `DDD2`
- 不提供任意十六进制写入入口
- 不访问未知特征
- 不包含固件升级功能

## 构建

在 PowerShell 中执行：

```powershell
$env:JAVA_HOME='E:\Android Studio\jbr'
.\gradlew.bat :app:assembleDebug
```

标准构建输出：

`app\build\outputs\apk\debug\app-debug.apk`
