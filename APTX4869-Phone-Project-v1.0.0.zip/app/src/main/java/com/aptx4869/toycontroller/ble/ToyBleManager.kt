package com.aptx4869.toycontroller.ble

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothStatusCodes
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

enum class BlePhase {
    Disconnected,
    Scanning,
    Connecting,
    Discovering,
    EnablingNotifications,
    Ready,
    Error,
}

data class BleConnectionState(
    val phase: BlePhase = BlePhase.Disconnected,
    val message: String = "尚未连接",
    val lastWrite: String = "—",
    val lastNotification: String = "—",
    val notificationChecksumValid: Boolean? = null,
    val batteryPercent: Int? = null,
)

class ToyBleManager(context: Context) {
    private val appContext = context.applicationContext
    private val bluetoothManager = appContext.getSystemService(BluetoothManager::class.java)
    private val handler = Handler(Looper.getMainLooper())
    private val writeMutex = Mutex()

    private val _state = MutableStateFlow(BleConnectionState())
    val state: StateFlow<BleConnectionState> = _state.asStateFlow()

    private var bluetoothGatt: BluetoothGatt? = null
    private var controlCharacteristic: BluetoothGattCharacteristic? = null
    private var activeScanCallback: ScanCallback? = null
    private var pendingWrite: CompletableDeferred<Int>? = null
    private var userDisconnecting = false

    val isBluetoothEnabled: Boolean
        get() = bluetoothManager.adapter?.isEnabled == true

    @SuppressLint("MissingPermission")
    fun connect() {
        if (_state.value.phase in setOf(BlePhase.Scanning, BlePhase.Connecting, BlePhase.Ready)) return

        val adapter = bluetoothManager.adapter
        if (adapter == null) {
            fail("此设备不支持蓝牙")
            return
        }
        if (!adapter.isEnabled) {
            fail("请先开启蓝牙")
            return
        }
        val scanner = adapter.bluetoothLeScanner
        if (scanner == null) {
            fail("无法使用 BLE 扫描器")
            return
        }

        closeGatt()
        userDisconnecting = false
        _state.value = _state.value.copy(batteryPercent = null)
        update(BlePhase.Scanning, "正在查找 ${ToyProtocol.targetName}…")

        val callback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val addressMatches = result.device.address.equals(ToyProtocol.targetAddress, true)
                val advertisedName = result.scanRecord?.deviceName ?: result.device.name
                val nameMatches = advertisedName == ToyProtocol.targetName
                if (!addressMatches && !nameMatches) return

                stopScan()
                update(BlePhase.Connecting, "已发现设备，正在连接…")
                bluetoothGatt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    result.device.connectGatt(
                        appContext,
                        false,
                        gattCallback,
                        BluetoothDeviceTransport.le,
                    )
                } else {
                    @Suppress("DEPRECATION")
                    result.device.connectGatt(appContext, false, gattCallback)
                }
            }

            override fun onScanFailed(errorCode: Int) {
                stopScan()
                fail("BLE 扫描失败：$errorCode")
            }
        }
        activeScanCallback = callback
        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()
        scanner.startScan(null, settings, callback)
        handler.postDelayed({
            if (_state.value.phase == BlePhase.Scanning) {
                stopScan()
                fail("未发现玩具，请确认已开机且未被其他设备连接")
            }
        }, scanTimeoutMs)
    }

    @SuppressLint("MissingPermission")
    fun disconnect() {
        userDisconnecting = true
        stopScan()
        pendingWrite?.complete(BluetoothGatt.GATT_FAILURE)
        pendingWrite = null
        bluetoothGatt?.disconnect()
        closeGatt()
        _state.value = _state.value.copy(
            phase = BlePhase.Disconnected,
            message = "已断开连接",
            batteryPercent = null,
        )
    }

    @SuppressLint("MissingPermission")
    suspend fun writeControl(frame: ByteArray): Boolean = writeMutex.withLock {
        val gatt = bluetoothGatt
        val characteristic = controlCharacteristic
        if (gatt == null || characteristic == null || _state.value.phase != BlePhase.Ready) {
            _state.value = _state.value.copy(message = "设备尚未就绪")
            return@withLock false
        }

        repeat(writeStartAttempts) { attempt ->
            val completion = CompletableDeferred<Int>()
            pendingWrite = completion
            val started = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                gatt.writeCharacteristic(
                    characteristic,
                    frame,
                    BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT,
                ) == BluetoothStatusCodes.SUCCESS
            } else {
                @Suppress("DEPRECATION")
                characteristic.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                @Suppress("DEPRECATION")
                characteristic.value = frame
                @Suppress("DEPRECATION")
                gatt.writeCharacteristic(characteristic)
            }

            if (!started) {
                if (pendingWrite === completion) pendingWrite = null
                if (attempt < writeStartAttempts - 1 && _state.value.phase == BlePhase.Ready) {
                    delay(writeRetryDelayMs)
                    return@repeat
                }
                _state.value = _state.value.copy(message = "蓝牙正忙，请稍后重试")
                return@withLock false
            }

            // 一旦 Android 接受了写入，即使调用方任务被取消，也必须等到 GATT 回调
            // 或超时后再释放互斥锁，避免下一条指令与仍在途的写入重叠。
            val status = withContext(NonCancellable) {
                withTimeoutOrNull(writeTimeoutMs) { completion.await() }
            }
            if (pendingWrite === completion) pendingWrite = null
            val success = status == BluetoothGatt.GATT_SUCCESS
            _state.value = _state.value.copy(
                message = if (success) "指令已发送" else "写入失败或超时",
                lastWrite = ToyProtocol.hex(frame),
            )
            return@withLock success
        }
        false
    }

    @SuppressLint("MissingPermission")
    fun close() {
        userDisconnecting = true
        stopScan()
        pendingWrite?.complete(BluetoothGatt.GATT_FAILURE)
        pendingWrite = null
        closeGatt()
    }

    private val gattCallback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                gatt.close()
                if (!userDisconnecting) fail("连接失败，GATT 状态：$status")
                return
            }
            when (newState) {
                BluetoothProfile.STATE_CONNECTED -> {
                    bluetoothGatt = gatt
                    update(BlePhase.Discovering, "已连接，正在发现服务…")
                    if (!gatt.discoverServices()) fail("无法启动 GATT 服务发现")
                }

                BluetoothProfile.STATE_DISCONNECTED -> {
                    gatt.close()
                    bluetoothGatt = null
                    controlCharacteristic = null
                    pendingWrite?.complete(BluetoothGatt.GATT_FAILURE)
                    pendingWrite = null
                    if (!userDisconnecting) {
                        _state.value = _state.value.copy(
                            phase = BlePhase.Disconnected,
                            message = "连接已断开",
                            batteryPercent = null,
                        )
                    }
                }
            }
        }

        @SuppressLint("MissingPermission")
        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                fail("服务发现失败：$status")
                return
            }
            val service = gatt.getService(ToyProtocol.serviceUuid)
            val control = service?.getCharacteristic(ToyProtocol.controlUuid)
            val notification = service?.getCharacteristic(ToyProtocol.statusUuid)
            if (service == null || control == null || notification == null) {
                fail("目标 DDDD/DDD1/DDD2 不完整")
                return
            }
            if (control.properties and BluetoothGattCharacteristic.PROPERTY_WRITE == 0) {
                fail("DDD1 不支持带响应写入")
                return
            }
            if (notification.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY == 0) {
                fail("DDD2 不支持通知")
                return
            }
            controlCharacteristic = control
            if (!gatt.setCharacteristicNotification(notification, true)) {
                fail("无法启用 DDD2 本地通知")
                return
            }
            val descriptor = notification.getDescriptor(ToyProtocol.cccdUuid)
            if (descriptor == null) {
                fail("DDD2 缺少 CCCD 描述符")
                return
            }
            update(BlePhase.EnablingNotifications, "正在启用状态通知…")
            val started = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                gatt.writeDescriptor(descriptor, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE) ==
                    BluetoothStatusCodes.SUCCESS
            } else {
                @Suppress("DEPRECATION")
                descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                @Suppress("DEPRECATION")
                gatt.writeDescriptor(descriptor)
            }
            if (!started) fail("无法写入 DDD2 通知配置")
        }

        override fun onDescriptorWrite(
            gatt: BluetoothGatt,
            descriptor: BluetoothGattDescriptor,
            status: Int,
        ) {
            if (descriptor.uuid != ToyProtocol.cccdUuid) return
            if (status == BluetoothGatt.GATT_SUCCESS) {
                update(BlePhase.Ready, "已连接，可以控制")
            } else {
                fail("启用 DDD2 通知失败：$status")
            }
        }

        override fun onCharacteristicWrite(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            status: Int,
        ) {
            if (characteristic.uuid == ToyProtocol.controlUuid) {
                pendingWrite?.complete(status)
            }
        }

        @Deprecated("Deprecated in Android 13")
        override fun onCharacteristicChanged(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
        ) {
            @Suppress("DEPRECATION")
            handleNotification(characteristic.uuid, characteristic.value ?: return)
        }

        override fun onCharacteristicChanged(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray,
        ) {
            handleNotification(characteristic.uuid, value)
        }
    }

    private fun handleNotification(uuid: java.util.UUID, value: ByteArray) {
        if (uuid != ToyProtocol.statusUuid) return
        val batteryPercent = ToyProtocol.batteryPercent(value)
        _state.value = _state.value.copy(
            lastNotification = ToyProtocol.hex(value),
            notificationChecksumValid = ToyProtocol.hasValidChecksum(value),
            batteryPercent = batteryPercent ?: _state.value.batteryPercent,
        )
    }

    @SuppressLint("MissingPermission")
    private fun stopScan() {
        val callback = activeScanCallback ?: return
        activeScanCallback = null
        runCatching { bluetoothManager.adapter?.bluetoothLeScanner?.stopScan(callback) }
    }

    @SuppressLint("MissingPermission")
    private fun closeGatt() {
        controlCharacteristic = null
        bluetoothGatt?.close()
        bluetoothGatt = null
    }

    private fun update(phase: BlePhase, message: String) {
        _state.value = _state.value.copy(phase = phase, message = message)
    }

    private fun fail(message: String) {
        _state.value = _state.value.copy(phase = BlePhase.Error, message = message)
    }

    private object BluetoothDeviceTransport {
        const val le = 2
    }

    private companion object {
        const val scanTimeoutMs = 15_000L
        const val writeTimeoutMs = 4_000L
        const val writeStartAttempts = 3
        const val writeRetryDelayMs = 35L
    }
}
