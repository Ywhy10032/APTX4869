package com.aptx4869.toycontroller.ble

import java.util.UUID

object ToyProtocol {
    const val targetAddress = "10:11:DD:02:16:E5"
    const val targetName = "ANKNI YWTD"

    val serviceUuid: UUID = UUID.fromString("0000dddd-0000-1000-8000-00805f9b34fb")
    val controlUuid: UUID = UUID.fromString("0000ddd1-0000-1000-8000-00805f9b34fb")
    val statusUuid: UUID = UUID.fromString("0000ddd2-0000-1000-8000-00805f9b34fb")
    val cccdUuid: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

    fun modeFrame(mode: Int): ByteArray {
        require(mode in 0..10) { "模式编号必须处于 0 到 10" }
        return withChecksum(byteArrayOf(0xAA.toByte(), 0x0F, 0x01, mode.toByte()))
    }

    fun linearFrame(intensity: Int): ByteArray {
        require(intensity in 0..100) { "线性强度必须处于 0 到 100" }
        val maximum = if (intensity == 0) 0 else 100
        return withChecksum(
            byteArrayOf(0xAA.toByte(), 0x08, 0x02, intensity.toByte(), maximum.toByte())
        )
    }

    val resumeFrame: ByteArray
        get() = withChecksum(byteArrayOf(0xAA.toByte(), 0x06, 0x01, 0x00))

    fun hasValidChecksum(frame: ByteArray): Boolean {
        if (frame.size < 2) return false
        val expected = frame.dropLast(1).sumOf { it.toInt() and 0xFF } and 0xFF
        return expected == (frame.last().toInt() and 0xFF)
    }

    fun batteryPercent(statusFrame: ByteArray): Int? {
        if (statusFrame.size != 10 || !hasValidChecksum(statusFrame)) return null
        if ((statusFrame[0].toInt() and 0xFF) != 0xAA ||
            (statusFrame[1].toInt() and 0xFF) != 0x01 ||
            (statusFrame[2].toInt() and 0xFF) != 0x06
        ) return null
        return (statusFrame[3].toInt() and 0xFF).takeIf { it in 0..100 }
    }

    fun hex(frame: ByteArray): String = frame.joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }

    private fun withChecksum(payload: ByteArray): ByteArray {
        val checksum = payload.sumOf { it.toInt() and 0xFF } and 0xFF
        return payload + checksum.toByte()
    }
}
