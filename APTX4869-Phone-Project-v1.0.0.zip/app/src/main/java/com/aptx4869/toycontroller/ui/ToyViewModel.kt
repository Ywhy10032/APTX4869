package com.aptx4869.toycontroller.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aptx4869.toycontroller.ble.BleConnectionState
import com.aptx4869.toycontroller.ble.BlePhase
import com.aptx4869.toycontroller.ble.ToyBleManager
import com.aptx4869.toycontroller.ble.ToyProtocol
import kotlin.random.Random
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

data class ToyControlState(
    val activeMode: Int? = null,
    val linearIntensity: Int = 50,
    val linearRunning: Boolean = false,
    val linearPaused: Boolean = false,
)

data class ToyUiState(
    val ble: BleConnectionState = BleConnectionState(),
    val control: ToyControlState = ToyControlState(),
) {
    val isReady: Boolean get() = ble.phase == BlePhase.Ready
}

class ToyViewModel(application: Application) : AndroidViewModel(application) {
    private val bleManager = ToyBleManager(application)
    private val controlState = kotlinx.coroutines.flow.MutableStateFlow(ToyControlState())
    private val linearUpdateSignal = Channel<Unit>(Channel.CONFLATED)
    private var linearRepeatJob: Job? = null

    val uiState = combine(bleManager.state, controlState) { ble, control ->
        ToyUiState(ble = ble, control = control)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = ToyUiState(),
    )

    val isBluetoothEnabled: Boolean get() = bleManager.isBluetoothEnabled

    fun connect() = bleManager.connect()

    fun disconnect() {
        linearRepeatJob?.cancel()
        controlState.value = ToyControlState(linearIntensity = controlState.value.linearIntensity)
        bleManager.disconnect()
    }

    fun selectMode(mode: Int) {
        if (mode !in 1..10 || !uiState.value.isReady) return
        val target = if (controlState.value.activeMode == mode) 0 else mode
        linearRepeatJob?.cancel()
        viewModelScope.launch {
            if (bleManager.writeControl(ToyProtocol.modeFrame(target))) {
                controlState.value = controlState.value.copy(
                    activeMode = target.takeIf { it != 0 },
                    linearRunning = false,
                    linearPaused = false,
                )
            }
        }
    }

    fun setLinearIntensity(intensity: Int) {
        if (!uiState.value.isReady) return
        val safeIntensity = intensity.coerceIn(0, 100)
        val current = controlState.value
        val alreadyApplied = current.activeMode == null &&
            !current.linearPaused &&
            current.linearIntensity == safeIntensity &&
            current.linearRunning == (safeIntensity > 0)
        if (alreadyApplied) return

        controlState.value = controlState.value.copy(
            activeMode = null,
            linearIntensity = safeIntensity,
            linearRunning = safeIntensity > 0,
            linearPaused = false,
        )
        startLinearRepeat()
    }

    fun burst() = setLinearIntensity(100)

    fun randomIntensity() = setLinearIntensity(Random.nextInt(1, 101))

    fun togglePause() {
        if (!uiState.value.isReady) return
        if (controlState.value.linearPaused) {
            val restored = controlState.value.linearIntensity.takeIf { it > 0 } ?: 50
            controlState.value = controlState.value.copy(
                activeMode = null,
                linearIntensity = restored,
                linearRunning = true,
                linearPaused = false,
            )
            viewModelScope.launch {
                bleManager.writeControl(ToyProtocol.resumeFrame)
                delay(60)
                startLinearRepeat()
            }
        } else {
            linearRepeatJob?.cancel()
            controlState.value = controlState.value.copy(
                activeMode = null,
                linearRunning = false,
                linearPaused = true,
            )
            viewModelScope.launch {
                val stop = ToyProtocol.linearFrame(0)
                bleManager.writeControl(stop)
                delay(60)
                bleManager.writeControl(stop)
            }
        }
    }

    fun stopAll() {
        if (!uiState.value.isReady) return
        linearRepeatJob?.cancel()
        controlState.value = controlState.value.copy(
            activeMode = null,
            linearRunning = false,
            linearPaused = false,
        )
        viewModelScope.launch {
            bleManager.writeControl(ToyProtocol.modeFrame(0))
            delay(60)
            val linearStop = ToyProtocol.linearFrame(0)
            bleManager.writeControl(linearStop)
            delay(60)
            bleManager.writeControl(linearStop)
        }
    }

    private fun startLinearRepeat() {
        linearUpdateSignal.trySend(Unit)
        if (linearRepeatJob?.isActive == true) return
        linearRepeatJob = viewModelScope.launch {
            while (isActive && uiState.value.isReady) {
                while (linearUpdateSignal.tryReceive().isSuccess) {
                    // 丢弃已过期的拖动事件，只发送 controlState 中的最新强度。
                }
                val latestIntensity = controlState.value.linearIntensity
                if (controlState.value.linearPaused) break
                bleManager.writeControl(ToyProtocol.linearFrame(latestIntensity))

                val latestState = controlState.value
                if (latestIntensity == 0 && latestState.linearIntensity == 0) break
                withTimeoutOrNull(linearRepeatIntervalMs) {
                    linearUpdateSignal.receive()
                }
            }
        }
    }

    override fun onCleared() {
        linearRepeatJob?.cancel()
        bleManager.close()
        super.onCleared()
    }

    private companion object {
        const val linearRepeatIntervalMs = 100L
    }
}
