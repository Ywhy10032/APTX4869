package com.aptx4869.toycontroller.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aptx4869.toycontroller.ble.BlePhase
import com.aptx4869.toycontroller.ble.ToyProtocol
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ToyScreen(
    state: ToyUiState,
    darkMode: Boolean,
    onToggleDarkMode: () -> Unit,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit,
    onSelectMode: (Int) -> Unit,
    onLinearIntensity: (Int) -> Unit,
    onBurst: () -> Unit,
    onRandom: () -> Unit,
    onTogglePause: () -> Unit,
    onStopAll: () -> Unit,
) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("APTX4869", fontWeight = FontWeight.SemiBold)
                        Text(
                            "ANKNI YWTD",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                },
                actions = {
                    FilledTonalIconButton(onClick = onToggleDarkMode) {
                        Text(
                            if (darkMode) "☀" else "☾",
                            fontSize = 22.sp,
                            textAlign = TextAlign.Center,
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                ),
            )
        },
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
        ) {
            val compact = maxHeight < 650.dp
            val gap = if (compact) 8.dp else 12.dp
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(gap),
            ) {
                CompactConnectionCard(state, onConnect, onDisconnect)
                ModeCard(
                    state = state,
                    compact = compact,
                    onSelectMode = onSelectMode,
                )
                LinearCard(
                    state = state,
                    compact = compact,
                    onLinearIntensity = onLinearIntensity,
                    onBurst = onBurst,
                    onRandom = onRandom,
                    onTogglePause = onTogglePause,
                )
                Spacer(Modifier.weight(1f))
                Button(
                    onClick = onStopAll,
                    enabled = state.isReady,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(if (compact) 50.dp else 56.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer,
                        contentColor = MaterialTheme.colorScheme.onErrorContainer,
                    ),
                ) {
                    Text("停止全部振动", fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
private fun CompactConnectionCard(
    state: ToyUiState,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit,
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainer,
        ),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                val indicatorColor = when (state.ble.phase) {
                    BlePhase.Ready -> Color(0xFF34A853)
                    BlePhase.Error -> MaterialTheme.colorScheme.error
                    BlePhase.Disconnected -> MaterialTheme.colorScheme.outline
                    else -> Color(0xFF4285F4)
                }
                Box(
                    Modifier
                        .size(12.dp)
                        .clip(CircleShape)
                        .background(indicatorColor)
                )
                Column {
                    Text(ToyProtocol.targetName, fontWeight = FontWeight.SemiBold)
                    Text(
                        state.ble.message,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (state.ble.phase == BlePhase.Ready) {
                    BatteryBadge(state.ble.batteryPercent)
                    OutlinedButton(onClick = onDisconnect) { Text("断开") }
                } else {
                    Button(
                        onClick = onConnect,
                        enabled = state.ble.phase !in setOf(
                            BlePhase.Scanning,
                            BlePhase.Connecting,
                            BlePhase.Discovering,
                            BlePhase.EnablingNotifications,
                        ),
                    ) { Text("连接") }
                }
            }
        }
    }
}

@Composable
private fun BatteryBadge(percent: Int?) {
    val contentColor = when {
        percent == null -> MaterialTheme.colorScheme.onSurfaceVariant
        percent <= 20 -> MaterialTheme.colorScheme.error
        percent <= 40 -> Color(0xFFF9AB00)
        else -> Color(0xFF34A853)
    }
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(contentColor.copy(alpha = 0.12f))
            .padding(horizontal = 10.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = percent?.let { "电量 $it%" } ?: "电量 --",
            color = contentColor,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

@Composable
private fun ModeCard(
    state: ToyUiState,
    compact: Boolean,
    onSelectMode: (Int) -> Unit,
) {
    val circleSize = if (compact) 44.dp else 52.dp
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainer,
        ),
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = if (compact) 10.dp else 14.dp),
            verticalArrangement = Arrangement.spacedBy(if (compact) 8.dp else 12.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text("节奏模式", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(
                    state.control.activeMode?.let { "模式 $it 运行中" } ?: "选择模式",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            repeat(2) { rowIndex ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    repeat(5) { columnIndex ->
                        val mode = rowIndex * 5 + columnIndex + 1
                        val active = state.control.activeMode == mode
                        val background by animateColorAsState(
                            if (active) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.surfaceContainerHighest,
                            label = "modeBackground",
                        )
                        val foreground by animateColorAsState(
                            if (active) MaterialTheme.colorScheme.onPrimary
                            else MaterialTheme.colorScheme.onSurface,
                            label = "modeForeground",
                        )
                        Box(
                            modifier = Modifier
                                .size(circleSize)
                                .clip(CircleShape)
                                .background(background)
                                .clickable(enabled = state.isReady) { onSelectMode(mode) },
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                mode.toString(),
                                color = foreground,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = if (compact) 17.sp else 19.sp,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LinearCard(
    state: ToyUiState,
    compact: Boolean,
    onLinearIntensity: (Int) -> Unit,
    onBurst: () -> Unit,
    onRandom: () -> Unit,
    onTogglePause: () -> Unit,
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainer,
        ),
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = if (compact) 10.dp else 14.dp),
            verticalArrangement = Arrangement.spacedBy(if (compact) 7.dp else 10.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column {
                    Text("线性强度", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(
                        if (state.control.linearPaused) "已暂停" else if (state.control.linearRunning) "实时应用中" else "拖动圆点调整",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Text(
                    "${state.control.linearIntensity}%",
                    fontSize = if (compact) 30.sp else 36.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            RealtimeCircularSlider(
                value = state.control.linearIntensity,
                enabled = state.isReady,
                onValueChange = onLinearIntensity,
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Button(
                    onClick = onBurst,
                    enabled = state.isReady,
                    modifier = Modifier.weight(1f),
                ) { Text("爆发") }
                OutlinedButton(
                    onClick = onRandom,
                    enabled = state.isReady,
                    modifier = Modifier.weight(1f),
                ) { Text("随机") }
                OutlinedButton(
                    onClick = onTogglePause,
                    enabled = state.isReady,
                    modifier = Modifier.weight(1f),
                ) { Text(if (state.control.linearPaused) "继续" else "暂停") }
            }
        }
    }
}

@Composable
private fun RealtimeCircularSlider(
    value: Int,
    enabled: Boolean,
    onValueChange: (Int) -> Unit,
) {
    var localValue by remember(value) { mutableIntStateOf(value) }
    val density = LocalDensity.current
    val thumbSize = 30.dp
    val thumbSizePx = with(density) { thumbSize.toPx() }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxWidth()
            .height(48.dp),
        contentAlignment = Alignment.CenterStart,
    ) {
        val usableWidthPx = (constraints.maxWidth - thumbSizePx).coerceAtLeast(1f)
        fun updateFromPosition(position: Offset) {
            if (!enabled) return
            val raw = ((position.x - thumbSizePx / 2f) / usableWidthPx * 100f)
                .coerceIn(0f, 100f)
                .roundToInt()
            if (raw != localValue) {
                localValue = raw
                onValueChange(raw)
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(40.dp)
                .pointerInput(enabled) {
                    detectDragGestures(
                        onDragStart = ::updateFromPosition,
                        onDrag = { change, _ ->
                            change.consume()
                            updateFromPosition(change.position)
                        },
                    )
                },
            contentAlignment = Alignment.CenterStart,
        ) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceContainerHighest)
            )
            Box(
                Modifier
                    .fillMaxWidth(localValue / 100f)
                    .height(6.dp)
                    .clip(CircleShape)
                    .background(
                        if (enabled) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.outline
                    )
            )
            Box(
                modifier = Modifier
                    .offset {
                        IntOffset(
                            x = (usableWidthPx * localValue / 100f).roundToInt(),
                            y = 0,
                        )
                    }
                    .size(thumbSize)
                    .shadow(3.dp, CircleShape)
                    .clip(CircleShape)
                    .background(
                        if (enabled) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.outline
                    ),
            )
        }
    }
}
