package com.aptx4869.toycontroller.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.aptx4869.toycontroller.ui.theme.AptxTheme
import com.aptx4869.toycontroller.ui.theme.ThemePreference
import kotlin.math.hypot
import kotlinx.coroutines.launch

@Composable
fun ThemeRevealHost(
    darkMode: Boolean,
    onDarkModeChanged: (Boolean) -> Unit,
    content: @Composable (renderedDarkMode: Boolean, onToggle: () -> Unit) -> Unit,
) {
    val scope = rememberCoroutineScope()
    val progress = remember { Animatable(1f) }
    var baseDarkMode by remember { mutableStateOf(darkMode) }
    var targetDarkMode by remember { mutableStateOf(darkMode) }
    var transitionRunning by remember { mutableStateOf(false) }

    LaunchedEffect(darkMode) {
        if (!transitionRunning) {
            baseDarkMode = darkMode
            targetDarkMode = darkMode
        }
    }

    fun startTransition() {
        if (transitionRunning) return
        val nextDarkMode = !baseDarkMode
        scope.launch {
            progress.snapTo(0f)
            targetDarkMode = nextDarkMode
            transitionRunning = true
            progress.animateTo(
                targetValue = 1f,
                animationSpec = tween(
                    durationMillis = revealDurationMillis,
                    easing = FastOutSlowInEasing,
                ),
            )
            baseDarkMode = targetDarkMode
            onDarkModeChanged(targetDarkMode)
            transitionRunning = false
        }
    }

    BoxWithConstraints {
        val density = LocalDensity.current
        val origin = with(density) {
            Offset(
                x = constraints.maxWidth - 28.dp.toPx(),
                y = 56.dp.toPx(),
            )
        }
        val maximumRadius = maximumCornerDistance(
            origin = origin,
            width = constraints.maxWidth.toFloat(),
            height = constraints.maxHeight.toFloat(),
        )

        key(baseDarkMode) {
            AptxTheme(
                preference = if (baseDarkMode) ThemePreference.Dark else ThemePreference.Light,
                updateSystemBars = true,
            ) {
                content(baseDarkMode, ::startTransition)
            }
        }

        if (transitionRunning) {
            val revealRadius = maximumRadius * progress.value
            AptxTheme(
                preference = if (targetDarkMode) ThemePreference.Dark else ThemePreference.Light,
                updateSystemBars = false,
            ) {
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .graphicsLayer {
                            clip = true
                            shape = CircularRevealShape(origin, revealRadius)
                        },
                ) {
                    content(targetDarkMode) { }
                }
            }

            val waveColor = if (targetDarkMode) {
                Color(0xFFB8C7FF)
            } else {
                Color(0xFFE94F87)
            }
            Canvas(Modifier.matchParentSize()) {
                val fade = (1f - progress.value).coerceIn(0f, 1f)
                drawCircle(
                    color = waveColor.copy(alpha = 0.42f * fade),
                    radius = revealRadius,
                    center = origin,
                    style = Stroke(width = 3.dp.toPx()),
                )
                drawCircle(
                    color = waveColor.copy(alpha = 0.24f * fade),
                    radius = revealRadius * 0.86f,
                    center = origin,
                    style = Stroke(width = 2.dp.toPx()),
                )
            }

            Box(
                modifier = Modifier
                    .matchParentSize()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = { },
                    ),
            )
        }
    }
}

private class CircularRevealShape(
    private val origin: Offset,
    private val radius: Float,
) : Shape {
    override fun createOutline(
        size: androidx.compose.ui.geometry.Size,
        layoutDirection: LayoutDirection,
        density: Density,
    ): Outline {
        val path = Path().apply {
            addOval(
                Rect(
                    left = origin.x - radius,
                    top = origin.y - radius,
                    right = origin.x + radius,
                    bottom = origin.y + radius,
                )
            )
        }
        return Outline.Generic(path)
    }
}

private fun maximumCornerDistance(origin: Offset, width: Float, height: Float): Float = maxOf(
    hypot(origin.x, origin.y),
    hypot(width - origin.x, origin.y),
    hypot(origin.x, height - origin.y),
    hypot(width - origin.x, height - origin.y),
)

private const val revealDurationMillis = 680
