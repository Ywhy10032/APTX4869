package com.aptx4869.toycontroller

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.core.content.edit
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aptx4869.toycontroller.ui.ToyScreen
import com.aptx4869.toycontroller.ui.ThemeRevealHost
import com.aptx4869.toycontroller.ui.ToyViewModel
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    private var lightPaletteVariant: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val uiPreferences = getSharedPreferences(UI_PREFERENCES, MODE_PRIVATE)
        lightPaletteVariant = savedInstanceState?.getInt(LIGHT_PALETTE_STATE_KEY)
            ?: chooseNextLightPalette(uiPreferences)

        setContent {
            val toyViewModel: ToyViewModel = viewModel()
            val state by toyViewModel.uiState.collectAsStateWithLifecycle()
            val preferences = remember { uiPreferences }
            val systemDark = isSystemInDarkTheme()
            var darkMode by rememberSaveable {
                mutableStateOf(preferences.getBoolean("dark_mode", systemDark))
            }

            val bluetoothEnableLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.StartActivityForResult()
            ) { result ->
                if (result.resultCode == Activity.RESULT_OK || toyViewModel.isBluetoothEnabled) {
                    toyViewModel.connect()
                } else {
                    Toast.makeText(this, "需要开启蓝牙才能连接玩具", Toast.LENGTH_SHORT).show()
                }
            }

            val permissionLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.RequestMultiplePermissions()
            ) { results ->
                if (results.values.all { it }) {
                    if (toyViewModel.isBluetoothEnabled) {
                        toyViewModel.connect()
                    } else {
                        bluetoothEnableLauncher.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
                    }
                } else {
                    Toast.makeText(this, "需要附近设备权限才能扫描和连接", Toast.LENGTH_LONG).show()
                }
            }

            val connectAction = {
                val permissions = requiredBluetoothPermissions()
                val missing = permissions.filter {
                    ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
                }
                when {
                    missing.isNotEmpty() -> permissionLauncher.launch(missing.toTypedArray())
                    !toyViewModel.isBluetoothEnabled ->
                        bluetoothEnableLauncher.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
                    else -> toyViewModel.connect()
                }
            }

            ThemeRevealHost(
                darkMode = darkMode,
                onDarkModeChanged = {
                    darkMode = it
                    preferences.edit { putBoolean("dark_mode", it) }
                },
            ) { renderedDarkMode, toggleTheme ->
                ToyScreen(
                    state = state,
                    darkMode = renderedDarkMode,
                    lightPaletteVariant = lightPaletteVariant,
                    onToggleDarkMode = toggleTheme,
                    onConnect = connectAction,
                    onDisconnect = toyViewModel::disconnect,
                    onSelectMode = toyViewModel::selectMode,
                    onLinearIntensity = toyViewModel::setLinearIntensity,
                    onBurst = toyViewModel::burst,
                    onRandom = toyViewModel::randomIntensity,
                    onTogglePause = toyViewModel::togglePause,
                    onStopAll = toyViewModel::stopAll,
                )
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putInt(LIGHT_PALETTE_STATE_KEY, lightPaletteVariant)
        super.onSaveInstanceState(outState)
    }

    private fun chooseNextLightPalette(preferences: SharedPreferences): Int {
        val previous = preferences.getInt(LIGHT_PALETTE_PREFERENCE_KEY, -1)
        val selected = if (previous in 0 until LIGHT_PALETTE_VARIANT_COUNT) {
            (previous + Random.nextInt(1, LIGHT_PALETTE_VARIANT_COUNT)) %
                LIGHT_PALETTE_VARIANT_COUNT
        } else {
            Random.nextInt(LIGHT_PALETTE_VARIANT_COUNT)
        }
        preferences.edit { putInt(LIGHT_PALETTE_PREFERENCE_KEY, selected) }
        return selected
    }

    private fun requiredBluetoothPermissions(): List<String> =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            listOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            listOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }

    private companion object {
        const val UI_PREFERENCES = "aptx4869_ui"
        const val LIGHT_PALETTE_STATE_KEY = "light_palette_state"
        const val LIGHT_PALETTE_PREFERENCE_KEY = "light_palette_previous"
        const val LIGHT_PALETTE_VARIANT_COUNT = 6
    }
}
