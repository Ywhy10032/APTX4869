# No custom rules are required for the current non-minified release build.

