package com.aptx4869.toycontroller.watch.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val WatchColors = darkColorScheme(
    primary = Color(0xFFA8C7FA),
    onPrimary = Color(0xFF062E6F),
    secondary = Color(0xFFC2E7FF),
    background = Color.Black,
    surface = Color(0xFF0E1116),
    onSurface = Color(0xFFE3E8F0),
    onSurfaceVariant = Color(0xFF9AA5B5),
    error = Color(0xFFFFB4AB),
)

@Composable
fun AptxWatchTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = WatchColors,
        content = content,
    )
}
