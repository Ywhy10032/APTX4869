package com.aptx4869.toycontroller.watch

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.view.Choreographer
import android.view.InputDevice
import android.view.KeyEvent
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.view.WindowCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aptx4869.toycontroller.watch.ui.WatchScreen
import com.aptx4869.toycontroller.watch.ui.ControlPage
import com.aptx4869.toycontroller.watch.ui.WatchViewModel
import com.aptx4869.toycontroller.watch.ui.theme.AptxWatchTheme

class MainActivity : ComponentActivity() {
    private val viewModel: WatchViewModel by viewModels()
    private val systemKeyGuard by lazy { Oww251SystemKeyGuard(this) }

    private var permissionGranted by mutableStateOf(false)
    private var bluetoothEnabled by mutableStateOf(false)
    private val exitProgress = mutableFloatStateOf(0f)

    private val choreographer by lazy { Choreographer.getInstance() }
    private var crownPressStartedAt = 0L
    private var crownLongPressTriggered = false
    private var lastCrownStepAt = 0L
    private var lastCrownDirection = 0
    private val crownProgressUpdater = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (crownPressStartedAt == 0L || crownLongPressTriggered) return

            val elapsed = SystemClock.uptimeMillis() - crownPressStartedAt
            exitProgress.floatValue = if (elapsed < PROGRESS_REVEAL_DELAY_MILLIS) {
                0f
            } else {
                ((elapsed - PROGRESS_REVEAL_DELAY_MILLIS).toFloat() /
                    (EXIT_HOLD_MILLIS - PROGRESS_REVEAL_DELAY_MILLIS)).coerceIn(0f, 1f)
            }
            if (elapsed >= EXIT_HOLD_MILLIS) {
                crownLongPressTriggered = true
                exitProgress.floatValue = 1f
                window.decorView.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                viewModel.stopForExit {
                    finishAndRemoveTask()
                }
            } else {
                choreographer.postFrameCallback(this)
            }
        }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        refreshDeviceState()
    }

    private val bluetoothLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        refreshDeviceState()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        refreshDeviceState()

        setContent {
            val state = viewModel.uiState.collectAsStateWithLifecycle().value
            AptxWatchTheme {
                WatchScreen(
                    state = state,
                    permissionGranted = permissionGranted,
                    bluetoothEnabled = bluetoothEnabled,
                    exitProgress = exitProgress,
                    onRequestPermission = ::requestBluetoothPermissions,
                    onEnableBluetooth = ::requestEnableBluetooth,
                    onConnect = viewModel::connect,
                    onRotate = ::handleCrownStep,
                    onToggleRunning = viewModel::toggleRunning,
                    onSwitchPage = viewModel::switchPage,
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        systemKeyGuard.activate()
        refreshDeviceState()
    }

    override fun onPause() {
        cancelCrownPress(resetProgress = true)
        systemKeyGuard.deactivate()
        super.onPause()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode !in handledKeyCodes) return super.dispatchKeyEvent(event)

        // OWW251 实测：表冠短按上报为 F1。抬起前不执行短按，以便区分长按退出。
        if (event.keyCode == KeyEvent.KEYCODE_F1 ||
            event.keyCode == KeyEvent.KEYCODE_STEM_PRIMARY
        ) {
            when (event.action) {
                KeyEvent.ACTION_DOWN -> if (event.repeatCount == 0) startCrownPress()
                KeyEvent.ACTION_UP -> finishCrownPress()
                KeyEvent.ACTION_MULTIPLE -> Unit
            }
            return true
        }

        // 同时消费按下与抬起事件，避免事件继续传给普通应用层按键处理。
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_CENTER,
                KeyEvent.KEYCODE_ENTER -> viewModel.toggleRunning()

                // OWW251 实测：下方实体键上报为 F2。
                KeyEvent.KEYCODE_F2,
                KeyEvent.KEYCODE_STEM_1,
                KeyEvent.KEYCODE_STEM_2 -> viewModel.switchPage()
            }
        }
        return true
    }

    override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
        val verticalScroll = event.getAxisValue(MotionEvent.AXIS_VSCROLL)
        val isOppoCrown = event.device?.name == CROWN_DEVICE_NAME
        val isRotaryEncoder = event.isFromSource(InputDevice.SOURCE_ROTARY_ENCODER)
        val isMouseWheel = event.isFromSource(InputDevice.SOURCE_MOUSE)

        if (event.action == MotionEvent.ACTION_SCROLL &&
            verticalScroll != 0f &&
            (isOppoCrown || isRotaryEncoder || isMouseWheel)
        ) {
            val direction = if (verticalScroll > 0f) -1 else 1
            val now = SystemClock.uptimeMillis()
            val directionChanged = direction != lastCrownDirection
            val stepInterval = when (viewModel.uiState.value.control.page) {
                ControlPage.Linear -> LINEAR_CROWN_STEP_INTERVAL_MILLIS
                ControlPage.Rhythm -> RHYTHM_CROWN_STEP_INTERVAL_MILLIS
            }
            if (directionChanged || now - lastCrownStepAt >= stepInterval) {
                lastCrownStepAt = now
                lastCrownDirection = direction
                handleCrownStep(direction)
            }
            return true
        }
        return super.dispatchGenericMotionEvent(event)
    }

    private fun handleCrownStep(direction: Int) {
        val before = viewModel.uiState.value.control
        viewModel.rotate(direction)
        val after = viewModel.uiState.value.control
        if (after == before) return

        val hapticType = when (after.page) {
            ControlPage.Linear -> HapticFeedbackConstants.CLOCK_TICK
            ControlPage.Rhythm -> HapticFeedbackConstants.CONTEXT_CLICK
        }
        // 使用系统优化过的触觉类型：线性为轻齿感，节奏为更清晰的段落感。
        window.decorView.performHapticFeedback(hapticType)
    }

    private fun startCrownPress() {
        choreographer.removeFrameCallback(crownProgressUpdater)
        crownPressStartedAt = SystemClock.uptimeMillis()
        crownLongPressTriggered = false
        exitProgress.floatValue = 0f
        choreographer.postFrameCallback(crownProgressUpdater)
    }

    private fun finishCrownPress() {
        val wasLongPress = crownLongPressTriggered
        cancelCrownPress(resetProgress = !wasLongPress)
        if (!wasLongPress) viewModel.toggleRunning()
    }

    private fun cancelCrownPress(resetProgress: Boolean) {
        choreographer.removeFrameCallback(crownProgressUpdater)
        crownPressStartedAt = 0L
        if (resetProgress) {
            crownLongPressTriggered = false
            exitProgress.floatValue = 0f
        }
    }

    private fun refreshDeviceState() {
        permissionGranted = requiredPermissions().all(::hasPermission)
        bluetoothEnabled = viewModel.isBluetoothEnabled
        if (permissionGranted && bluetoothEnabled) viewModel.onPermissionGranted()
    }

    private fun requestBluetoothPermissions() {
        val missing = requiredPermissions().filterNot(::hasPermission)
        if (missing.isEmpty()) {
            refreshDeviceState()
        } else {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    @Suppress("DEPRECATION")
    private fun requestEnableBluetooth() {
        bluetoothLauncher.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
    }

    private fun requiredPermissions(): List<String> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            listOf(
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT,
            )
        } else {
            listOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    private fun hasPermission(permission: String): Boolean {
        return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED
    }

    private companion object {
        const val EXIT_HOLD_MILLIS = 2_000L
        const val PROGRESS_REVEAL_DELAY_MILLIS = 500L
        const val CROWN_DEVICE_NAME = "oplus_crown"

        const val LINEAR_CROWN_STEP_INTERVAL_MILLIS = 110L
        const val RHYTHM_CROWN_STEP_INTERVAL_MILLIS = 200L

        val handledKeyCodes = setOf(
            KeyEvent.KEYCODE_F1,
            KeyEvent.KEYCODE_F2,
            KeyEvent.KEYCODE_STEM_PRIMARY,
            KeyEvent.KEYCODE_STEM_1,
            KeyEvent.KEYCODE_STEM_2,
            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER,
        )
    }
}
