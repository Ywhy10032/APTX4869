package com.aptx4869.toycontroller.watch.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aptx4869.toycontroller.watch.ble.BleConnectionState
import com.aptx4869.toycontroller.watch.ble.BlePhase
import com.aptx4869.toycontroller.watch.ble.ToyBleManager
import com.aptx4869.toycontroller.watch.ble.ToyProtocol
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull

enum class ControlPage {
    Linear,
    Rhythm,
}

data class WatchControlState(
    val page: ControlPage = ControlPage.Linear,
    val intensity: Int = 50,
    val lastNonZeroIntensity: Int = 50,
    val mode: Int = 1,
    val isRunning: Boolean = false,
)

data class WatchUiState(
    val ble: BleConnectionState = BleConnectionState(),
    val control: WatchControlState = WatchControlState(),
) {
    val isReady: Boolean get() = ble.phase == BlePhase.Ready
    val isActuallyRunning: Boolean
        get() = isReady && control.isRunning &&
            (control.page != ControlPage.Linear || control.intensity > 0)
}

class WatchViewModel(application: Application) : AndroidViewModel(application) {
    private val bleManager = ToyBleManager(application)
    private val controlState = MutableStateFlow(WatchControlState())
    private val commandMutex = Mutex()
    private val linearUpdateSignal = Channel<Unit>(Channel.CONFLATED)
    private val modeUpdateSignal = Channel<Unit>(Channel.CONFLATED)

    private var linearWriterJob: Job? = null
    private var modeWriterJob: Job? = null
    private var autoConnectRequested = false

    val uiState = combine(bleManager.state, controlState) { ble, control ->
        WatchUiState(ble = ble, control = control)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = WatchUiState(),
    )

    val isBluetoothEnabled: Boolean get() = bleManager.isBluetoothEnabled

    fun onPermissionGranted() {
        if (autoConnectRequested) return
        autoConnectRequested = true
        connect()
    }

    fun connect() {
        if (!bleManager.isBluetoothEnabled) return
        bleManager.connect()
    }

    fun rotate(direction: Int) {
        if (direction == 0) return
        val current = controlState.value
        when (current.page) {
            ControlPage.Linear -> adjustIntensity(current, direction)
            ControlPage.Rhythm -> adjustMode(current, direction)
        }
    }

    fun toggleRunning() {
        if (!uiState.value.isReady) {
            connect()
            return
        }
        viewModelScope.launch {
            commandMutex.withLock {
                val current = controlState.value
                if (current.isRunning) {
                    stopPage(current.page)
                    controlState.value = controlState.value.copy(isRunning = false)
                } else {
                    startPage(current)
                }
            }
        }
    }

    fun stopForExit(onStopped: () -> Unit) {
        viewModelScope.launch {
            try {
                commandMutex.withLock {
                    val current = controlState.value
                    if (current.isRunning && uiState.value.isReady) {
                        stopPage(current.page)
                    }
                    controlState.value = controlState.value.copy(isRunning = false)
                }
            } finally {
                bleManager.close()
                onStopped()
            }
        }
    }

    fun switchPage() {
        val current = controlState.value
        val nextPage = if (current.page == ControlPage.Linear) {
            ControlPage.Rhythm
        } else {
            ControlPage.Linear
        }
        controlState.value = current.copy(page = nextPage, isRunning = false)
        linearWriterJob?.cancel()
        modeWriterJob?.cancel()

        if (current.isRunning && uiState.value.isReady) {
            viewModelScope.launch {
                commandMutex.withLock { stopPage(current.page) }
            }
        }
    }

    private fun adjustIntensity(current: WatchControlState, direction: Int) {
        val next = (current.intensity + direction.sign() * intensityStep).coerceIn(0, 100)
        if (next == current.intensity) return

        controlState.value = current.copy(
            intensity = next,
            lastNonZeroIntensity = if (next > 0) next else current.lastNonZeroIntensity,
            // 0% 只暂停输出，不解除线性模式的启动状态；再次调高会自动恢复。
            isRunning = current.isRunning,
        )

        if (!current.isRunning || !uiState.value.isReady) return
        if (next == 0) {
            linearWriterJob?.cancel()
            viewModelScope.launch {
                commandMutex.withLock {
                    bleManager.writeControl(ToyProtocol.linearFrame(0))
                }
            }
        } else {
            startLinearWriter()
        }
    }

    private fun adjustMode(current: WatchControlState, direction: Int) {
        val next = (current.mode + direction.sign()).coerceIn(1, modeCount)
        if (next == current.mode) return
        controlState.value = current.copy(mode = next)
        if (current.isRunning && uiState.value.isReady) startModeWriter()
    }

    private suspend fun startPage(current: WatchControlState) {
        when (current.page) {
            ControlPage.Linear -> {
                val target = if (current.intensity > 0) {
                    current.intensity
                } else {
                    current.lastNonZeroIntensity.coerceIn(intensityStep, 100)
                }
                controlState.value = current.copy(
                    intensity = target,
                    lastNonZeroIntensity = target,
                    isRunning = true,
                )
                startLinearWriter()
            }

            ControlPage.Rhythm -> {
                controlState.value = current.copy(isRunning = true)
                startModeWriter()
            }
        }
    }

    private suspend fun stopPage(page: ControlPage) {
        when (page) {
            ControlPage.Linear -> {
                linearWriterJob?.cancel()
                bleManager.writeControl(ToyProtocol.linearFrame(0))
            }

            ControlPage.Rhythm -> {
                modeWriterJob?.cancel()
                bleManager.writeControl(ToyProtocol.modeFrame(0))
            }
        }
    }

    private fun startLinearWriter() {
        linearUpdateSignal.trySend(Unit)
        if (linearWriterJob?.isActive == true) return
        linearWriterJob = viewModelScope.launch {
            while (isActive && uiState.value.isReady) {
                while (linearUpdateSignal.tryReceive().isSuccess) {
                    // 合并快速旋转事件，只发送当前最新强度。
                }
                val current = controlState.value
                if (current.page != ControlPage.Linear || !current.isRunning) break
                bleManager.writeControl(ToyProtocol.linearFrame(current.intensity))
                withTimeoutOrNull(linearRepeatIntervalMs) {
                    linearUpdateSignal.receive()
                }
            }
        }
    }

    private fun startModeWriter() {
        modeUpdateSignal.trySend(Unit)
        if (modeWriterJob?.isActive == true) return
        modeWriterJob = viewModelScope.launch {
            while (isActive && uiState.value.isReady) {
                while (modeUpdateSignal.tryReceive().isSuccess) {
                    // 合并快速旋转事件，只应用最后选中的模式。
                }
                val current = controlState.value
                if (current.page != ControlPage.Rhythm || !current.isRunning) break
                bleManager.writeControl(ToyProtocol.modeFrame(current.mode))
                modeUpdateSignal.receive()
            }
        }
    }

    override fun onCleared() {
        linearWriterJob?.cancel()
        modeWriterJob?.cancel()
        bleManager.close()
        super.onCleared()
    }

    private fun Int.sign(): Int = if (this > 0) 1 else -1

    private companion object {
        const val intensityStep = 5
        const val modeCount = 10
        const val linearRepeatIntervalMs = 100L
    }
}
