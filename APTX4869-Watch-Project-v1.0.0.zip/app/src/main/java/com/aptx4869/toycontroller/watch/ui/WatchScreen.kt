package com.aptx4869.toycontroller.watch.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.FloatState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.rotary.onRotaryScrollEvent
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aptx4869.toycontroller.watch.ble.BlePhase
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun WatchScreen(
    state: WatchUiState,
    permissionGranted: Boolean,
    bluetoothEnabled: Boolean,
    exitProgress: FloatState,
    onRequestPermission: () -> Unit,
    onEnableBluetooth: () -> Unit,
    onConnect: () -> Unit,
    onRotate: (Int) -> Unit,
    onToggleRunning: () -> Unit,
    onSwitchPage: () -> Unit,
) {
    val focusRequester = remember { FocusRequester() }
    val haptics = LocalHapticFeedback.current
    val rotaryModifier = Modifier
        .onRotaryScrollEvent { event ->
            val direction = if (event.verticalScrollPixels > 0f) -1 else 1
            onRotate(direction)
            true
        }
        .focusRequester(focusRequester)
        .focusable()

    LaunchedEffect(Unit) {
        focusRequester.requestFocus()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .then(rotaryModifier),
        contentAlignment = Alignment.Center,
    ) {
        ControlDial(
            state = state,
            enabled = permissionGranted && bluetoothEnabled,
            permissionGranted = permissionGranted,
            bluetoothEnabled = bluetoothEnabled,
            onClick = {
                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                when {
                    !permissionGranted -> onRequestPermission()
                    !bluetoothEnabled -> onEnableBluetooth()
                    !state.isReady -> onConnect()
                    else -> onToggleRunning()
                }
            },
            modifier = Modifier.offset(y = (-2).dp),
        )

        PageSelector(
            selected = state.control.page,
            onSwitchPage = {
                haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onSwitchPage()
            },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 13.dp),
        )

        ExitProgressRing(progress = exitProgress)
    }
}

@Composable
private fun ExitProgressRing(progress: FloatState) {
    Canvas(Modifier.fillMaxSize()) {
        val currentProgress = progress.floatValue
        if (currentProgress <= 0f) return@Canvas
        val strokeWidth = 4.dp.toPx()
        val inset = strokeWidth / 2f + 1.dp.toPx()
        drawArc(
            color = Color(0xFF4ADE80),
            startAngle = -90f,
            sweepAngle = 360f * currentProgress.coerceIn(0f, 1f),
            useCenter = false,
            topLeft = Offset(inset, inset),
            size = Size(size.width - inset * 2f, size.height - inset * 2f),
            style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
        )
    }
}

@Composable
private fun ConnectionBadge(
    state: WatchUiState,
    permissionGranted: Boolean,
    bluetoothEnabled: Boolean,
    modifier: Modifier = Modifier,
) {
    val (color, label) = when {
        !permissionGranted -> Color(0xFFFFD166) to "需要蓝牙权限"
        !bluetoothEnabled -> Color(0xFFFFD166) to "蓝牙未开启"
        state.ble.phase == BlePhase.Ready -> Color(0xFF75E39A) to
            (state.ble.batteryPercent?.let { "ANKNI · 电量 $it%" } ?: "ANKNI · 电量 --")
        state.ble.phase in setOf(
            BlePhase.Scanning,
            BlePhase.Connecting,
            BlePhase.Discovering,
            BlePhase.EnablingNotifications,
        ) -> MaterialTheme.colorScheme.primary to "正在连接…"
        state.ble.phase == BlePhase.Error -> MaterialTheme.colorScheme.error to "连接失败"
        else -> MaterialTheme.colorScheme.onSurfaceVariant to "ANKNI · 未连接"
    }

    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        Box(
            Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(color)
        )
        Text(
            text = label,
            color = color,
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium,
        )
    }
}

@Composable
private fun ControlDial(
    state: WatchUiState,
    enabled: Boolean,
    permissionGranted: Boolean,
    bluetoothEnabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val control = state.control
    val targetProgress = when (control.page) {
        ControlPage.Linear -> control.intensity / 100f
        ControlPage.Rhythm -> control.mode / 10f
    }
    val progress by animateFloatAsState(
        targetValue = targetProgress,
        animationSpec = tween(durationMillis = 90),
        label = "dialProgress",
    )
    val active = state.isActuallyRunning
    val primary = MaterialTheme.colorScheme.primary
    val disabledArc = MaterialTheme.colorScheme.onSurfaceVariant
    val track = Color(0xFF222831)
    val interactionSource = remember { MutableInteractionSource() }
    val tickCount = if (control.page == ControlPage.Linear) 20 else 10
    val tickVectors = remember(control.page) {
        (0..tickCount).map { index ->
            val fraction = index.toFloat() / tickCount
            val angle = (135f + 270f * fraction) * PI.toFloat() / 180f
            Triple(fraction, cos(angle), sin(angle))
        }
    }

    Box(
        modifier = modifier
            .size(218.dp)
            .clip(CircleShape)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                role = Role.Button,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val strokeWidth = 9.dp.toPx()
            val inset = strokeWidth / 2f + 4.dp.toPx()
            val arcSize = Size(size.width - inset * 2f, size.height - inset * 2f)
            val topLeft = Offset(inset, inset)

            if (active) {
                drawCircle(
                    color = primary.copy(alpha = 0.10f),
                    radius = size.minDimension / 2f - 1.dp.toPx(),
                )
            }
            drawArc(
                color = track,
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
            )
            drawArc(
                color = if (enabled) primary else disabledArc,
                startAngle = 135f,
                sweepAngle = 270f * progress,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
            )

            val tickRadius = size.minDimension / 2f - 1.dp.toPx()
            tickVectors.forEachIndexed { index, (fraction, xVector, yVector) ->
                val outer = Offset(
                    center.x + xVector * tickRadius,
                    center.y + yVector * tickRadius,
                )
                val innerRadius = tickRadius - if (index % 5 == 0) 5.dp.toPx() else 3.dp.toPx()
                val inner = Offset(
                    center.x + xVector * innerRadius,
                    center.y + yVector * innerRadius,
                )
                drawLine(
                    color = if (fraction <= progress + 0.001f) primary else track,
                    start = inner,
                    end = outer,
                    strokeWidth = if (index % 5 == 0) 1.5.dp.toPx() else 1.dp.toPx(),
                    cap = StrokeCap.Round,
                )
            }
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = if (control.page == ControlPage.Linear) "线性强度" else "节奏模式",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
            )
            Spacer(Modifier.height(1.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = if (control.page == ControlPage.Linear) {
                        control.intensity.toString()
                    } else {
                        control.mode.toString().padStart(2, '0')
                    },
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = 43.sp,
                    lineHeight = 45.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center,
                )
                if (control.page == ControlPage.Linear) {
                    Text(
                        text = "%",
                        modifier = Modifier.padding(bottom = 5.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
            }
            Text(
                text = when {
                    !enabled -> "轻触进行设置"
                    !state.isReady -> "轻触连接"
                    active -> "运行中 · 按下停止"
                    control.page == ControlPage.Linear && control.isRunning -> "待机 · 调高即启动"
                    else -> "按下启动"
                },
                color = if (active) primary else MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 10.sp,
                fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
            )
            Spacer(Modifier.height(4.dp))
            ConnectionBadge(
                state = state,
                permissionGranted = permissionGranted,
                bluetoothEnabled = bluetoothEnabled,
            )
        }
    }
}

@Composable
private fun PageSelector(
    selected: ControlPage,
    onSwitchPage: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val interactionSource = remember { MutableInteractionSource() }
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0xFF151A21))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onSwitchPage,
            )
            .padding(horizontal = 5.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        PagePill("线性", selected == ControlPage.Linear)
        PagePill("节奏", selected == ControlPage.Rhythm)
    }
}

@Composable
private fun PagePill(label: String, selected: Boolean) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) MaterialTheme.colorScheme.primary else Color.Transparent)
            .padding(horizontal = 10.dp, vertical = 3.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = if (selected) MaterialTheme.colorScheme.onPrimary
            else MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
        )
    }
}
