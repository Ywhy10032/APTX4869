package com.aptx4869.toycontroller.watch

import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.os.UserHandle
import android.provider.Settings
import android.util.Log

/**
 * OPPO Watch X2（OWW251）的 F1/F2 会先被系统服务处理，普通 dispatchKeyEvent
 * 无法阻止“返回表盘”和“微信支付”。本类只在 Activity 位于前台时临时关闭这两条
 * 系统映射，并在 Activity 离开前台时恢复进入应用前的原值。
 *
 * 所需权限由 ADB 一次性授予；没有权限时会安全失败，不会写入其他设置。
 */
class Oww251SystemKeyGuard(context: Context) {
    private val appContext = context.applicationContext
    private val resolver = appContext.contentResolver
    private val preferences = appContext.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)

    @Synchronized
    fun activate(): Boolean {
        if (!isSupportedDevice()) return false

        // 上一次进程若被系统直接杀死，先恢复当时保存的原值，再开始本次接管。
        if (preferences.getBoolean(KEY_GUARD_ACTIVE, false)) {
            restoreSavedValues()
        }

        val originalMarathon = Settings.Global.getString(resolver, SETTING_MARATHON_MODE)
        val originalShortcut = Settings.System.getString(resolver, SETTING_SINGLE_SHORTCUT)

        preferences.edit()
            .putBoolean(KEY_GUARD_ACTIVE, true)
            .putBoolean(KEY_MARATHON_PRESENT, originalMarathon != null)
            .putString(KEY_MARATHON_VALUE, originalMarathon)
            .putBoolean(KEY_SHORTCUT_PRESENT, originalShortcut != null)
            .putString(KEY_SHORTCUT_VALUE, originalShortcut)
            .commit()

        return try {
            val upperKeyReady = Settings.Global.putInt(resolver, SETTING_MARATHON_MODE, 1)
            val lowerKeyReady = putSystemSettingDirect(
                SETTING_SINGLE_SHORTCUT,
                DISABLED_SHORTCUT,
            )
            if (!upperKeyReady || !lowerKeyReady) {
                restoreSavedValues()
                Log.e(TAG, "系统按键接管写入失败：upper=$upperKeyReady, lower=$lowerKeyReady")
                false
            } else {
                Log.i(TAG, "系统按键接管已启用")
                true
            }
        } catch (error: RuntimeException) {
            restoreSavedValues()
            Log.e(TAG, "缺少系统按键接管权限", error)
            false
        }
    }

    @Synchronized
    fun deactivate() {
        if (!preferences.getBoolean(KEY_GUARD_ACTIVE, false)) return
        restoreSavedValues()
    }

    private fun restoreSavedValues() {
        val marathonPresent = preferences.getBoolean(KEY_MARATHON_PRESENT, false)
        val shortcutPresent = preferences.getBoolean(KEY_SHORTCUT_PRESENT, false)
        val originalMarathon = preferences.getString(KEY_MARATHON_VALUE, null)
        val originalShortcut = preferences.getString(KEY_SHORTCUT_VALUE, null)

        try {
            Settings.Global.putString(
                resolver,
                SETTING_MARATHON_MODE,
                if (marathonPresent) originalMarathon else null,
            )
            if (shortcutPresent && originalShortcut != null) {
                putSystemSettingDirect(SETTING_SINGLE_SHORTCUT, originalShortcut)
            } else {
                deleteSystemSettingDirect(SETTING_SINGLE_SHORTCUT)
            }
        } catch (error: RuntimeException) {
            Log.e(TAG, "恢复系统按键设置失败", error)
            return
        }

        preferences.edit().clear().commit()
        Log.i(TAG, "系统按键设置已恢复")
    }

    private fun isSupportedDevice(): Boolean =
        Build.MODEL.equals(SUPPORTED_MODEL, ignoreCase = true)

    /**
     * OWW251 把该厂商自定义键错误地加入了 Settings.System 的迁移黑名单，
     * 公开 putString 会在客户端直接抛出异常。这里调用同一个系统设置提供者的
     * 标准 PUT_system 接口，写入范围仍严格限定为传入的单个键。
     */
    private fun putSystemSettingDirect(name: String, value: String): Boolean {
        val extras = Bundle().apply {
            putString(CALL_VALUE_KEY, value)
            putInt(CALL_USER_KEY, currentUserId())
        }
        resolver.call(Settings.System.CONTENT_URI, CALL_PUT_SYSTEM, name, extras)
        return true
    }

    private fun deleteSystemSettingDirect(name: String): Boolean {
        val extras = Bundle().apply {
            putInt(CALL_USER_KEY, currentUserId())
        }
        resolver.call(Settings.System.CONTENT_URI, CALL_DELETE_SYSTEM, name, extras)
        return true
    }

    private fun currentUserId(): Int =
        // UserHandle.hashCode() 在 Android 中就是内部的用户编号。
        UserHandle.getUserHandleForUid(Process.myUid()).hashCode()

    private companion object {
        const val TAG = "Oww251KeyGuard"
        const val SUPPORTED_MODEL = "OWW251"
        const val PREFERENCES = "oww251_system_key_guard"

        const val SETTING_MARATHON_MODE = "in_marathon_mode"
        const val SETTING_SINGLE_SHORTCUT = "multifunction_single_shortcut_component"
        const val DISABLED_SHORTCUT = "none"

        const val CALL_PUT_SYSTEM = "PUT_system"
        const val CALL_DELETE_SYSTEM = "DELETE_system"
        const val CALL_VALUE_KEY = "value"
        const val CALL_USER_KEY = "_user"

        const val KEY_GUARD_ACTIVE = "guard_active"
        const val KEY_MARATHON_PRESENT = "marathon_present"
        const val KEY_MARATHON_VALUE = "marathon_value"
        const val KEY_SHORTCUT_PRESENT = "shortcut_present"
        const val KEY_SHORTCUT_VALUE = "shortcut_value"
    }
}
